# Review archive manifest

Supervisor review copy, not the final Neptun submission (the signed AI
declaration is still to come). Built from repository revision
`2ee0f47d608cfd74f552c24b01e9a3df55bfc4bb`; the code the thesis describes is
commit `141f6e2ee170065a0c943280117e4d1510a77e4a` (the later commits change
only the thesis, `campaign/analysis.md` wording and the execution record).

| File | SHA-256 |
|---|---|
| `thonmay-thesis.pdf` | `e154accfc2213550e534f834b365cb1dca05aa7f0fcc9a2aa0f3a7c9712de7b3` |
| `thesis-latex-source.zip` | `51f09d5fd4c82ba5d248b39271a1b8da09bb0eaf38a202d416955e1b66fe23cf` |
| `evoalgo-code.zip` | `34dcfee9a3bfd38a6d081167a191f3dd278ee6d30c77389f156b126a2e08f671` |
| `thesis-latex/approved-topic-registration.pdf` (inside the LaTeX zip) | `87179bb59bb0622cc8871e43781511b0821c0b4616930143c4f6c39244fdbd22` |

## Contents

- `thonmay-thesis.pdf`: the thesis, 161 pages; Chapters 1 to 7 are printed
  pages 6 to 85 (79 pages without the part divider).
- `thesis-latex-source.zip`: `thesis-latex/`, builds with `latexmk -pdf main.tex`
  to the same 161 pages. Contains the unsigned `ai-declaration.docx`.
- `evoalgo-code.zip`: `evoalgo/`, the source at the revision above plus the
  evidence the thesis cites:
  - `campaign/`: eval1 to eval3 plans, results and harness streams, the
    self-test, cross-check and memory logs, the UI check, and the execution
    record of the described commit (`campaign/execution_record/summary.md`,
    32/32 steps, 206 pytest passed).
  - `runs/`: the 52 evaluation runs, their aborted earlier attempts, the
    browser UI run and the reference run used by the tests (generations,
    candidates, reflections, prompt and call logs, events).

## Redaction

Build-host paths, the user and group names, site host names and the site's
model-gateway prefix are replaced by placeholders (`$REPO`, `$HOME`,
`$SCRATCH`, `$PREFIX`, `$TOOLS`, `site-endpoint`, ...). Model names, numbers,
timings and all outcomes are as recorded. Generation checkpoints were checked
against their stored SHA-256 before redaction and carry a recomputed one after
it; all 326 load. `python scripts/campaign.py report campaign/evalN.yaml`
(N = 1, 2, 3) in the unpacked code rebuilds `campaign/evalN/results.csv` and
`summary.md` byte for byte.

## Checked on this archive

- Fast pytest suite from the unpacked code (Python 3.11): 201 passed (the full
  206 with the slow n <= 5 corpus are in the execution record).
- The unpacked LaTeX source rebuilds to 161 pages, no undefined references.
- No build-host, user or site name is left in the code archive.
