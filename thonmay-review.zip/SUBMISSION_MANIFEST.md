# Review archive manifest

Supervisor review copy, not the final Neptun submission (the signed AI
declaration is still to come). Built from repository revision
`7e29ae34e6842bda2bdd364e12304a41b40c6dd0`; the code the thesis describes is
commit `141f6e2ee170065a0c943280117e4d1510a77e4a` (the later commits change
only the thesis, `campaign/analysis.md` wording and the execution record).

| File | SHA-256 |
|---|---|
| `thonmay-thesis.pdf` | `4688e81e079531a2edc4e8bc0a4483674197691202d1f8f68f24b4d90e94e0d9` |
| `thesis-latex-source.zip` | `6fc4d26a5316e480b9b4c3bab5389decb72260320d6197744c27f12f38c4f16a` |
| `evoalgo-code.zip` | `3df7aa1f915bdb32af464670badfe49a05da31f5cb3b8f13f42a4adbe70910bd` |
| `thesis-latex/approved-topic-registration.pdf` (inside the LaTeX zip) | `87179bb59bb0622cc8871e43781511b0821c0b4616930143c4f6c39244fdbd22` |

## Contents

- `thonmay-thesis.pdf`: the thesis, 161 pages; Chapters 1 to 7 are printed
  pages 6 to 85 (79 pages without the part divider).
- `thesis-latex-source.zip`: `thesis-latex/`, builds with `latexmk -pdf main.tex`
  to the same 161 pages. Contains the unsigned `ai-declaration.docx`.
- `evoalgo-code.zip`: `evoalgo/`, the source at the revision above plus the
  evidence the thesis cites:
  - `campaign/`: eval1 to eval3 plans, results and harness streams, the
    self-test, cross-check and memory logs, the UI check, and the execution
    record of the described commit (`campaign/execution_record/summary.md`,
    32/32 steps, 206 pytest passed).
  - `runs/`: the 52 evaluation runs, their aborted earlier attempts, the
    browser UI run and the reference run used by the tests (generations,
    candidates, reflections, prompt and call logs, events).

## Redaction

Build-host paths, the user and group names, site host names and the site's
model-gateway prefix are replaced by placeholders (`$REPO`, `$HOME`,
`$SCRATCH`, `$PREFIX`, `$TOOLS`, `site-endpoint`, ...). Model names, numbers,
timings and all outcomes are as recorded. Generation checkpoints were checked
against their stored SHA-256 before redaction and carry a recomputed one after
it; all 326 load. `python scripts/campaign.py report campaign/evalN.yaml`
(N = 1, 2, 3) in the unpacked code rebuilds `campaign/evalN/results.csv` and
`summary.md` byte for byte.

## Checked on this archive

- Fast pytest suite from the unpacked code (Python 3.11): 201 passed (the full
  206 with the slow n <= 5 corpus are in the execution record).
- The unpacked LaTeX source rebuilds to 161 pages, no undefined references.
- No build-host, user or site name is left in the code archive.
