# Review archive manifest

Supervisor review copy, not the final Neptun submission (the signed AI
declaration is still to come). Built from repository revision `7ef4fbda757cdecf417010208d468e88d2cc0113`;
the code the thesis describes is commit `f7ba4d1826c4c1ad6a2451c04fc654d7e271bd1c` (the later commit changes
only the thesis and the execution record).

| File | SHA-256 |
|---|---|
| `thonmay-thesis.pdf` | `a7b1bf8da0bf77d05c2f0960897d986d20c1fe319f88950b10c888ec014eb84b` |
| `thesis-latex-source.zip` | `34adaac8ae2195f55f927409b9c94fe1e4acf1c1b0f38e72d41c489d89c830a9` |
| `evoalgo-code.zip` | `31ac5abc0872b23042795fb490fe2bd70aaf1063edffb42ca09889a86fb371d8` |

## Contents

- `thonmay-thesis.pdf`: the thesis, 160 pages; Chapters 1 to 7 are printed
  pages 6 to 85 (79 pages without the part divider).
- `thesis-latex-source.zip`: `thesis-latex/`, builds with `latexmk -pdf main.tex`
  to the same 160 pages. Contains the unsigned `ai-declaration.docx`.
- `evoalgo-code.zip`: `evoalgo/`, the source at the revision above plus the
  evidence the thesis cites:
  - `campaign/`: eval1 to eval3 plans, results and harness streams, the
    self-test, cross-check and memory logs, the UI check, and the execution
    record of the described commit (`campaign/execution_record/summary.md`,
    32/32 steps).
  - `runs/`: the 52 evaluation runs, their aborted earlier attempts, the
    browser UI run and the reference run used by the tests (generations,
    candidates, reflections, prompt and call logs, events).

## Redaction

Build-host paths, the user and group names, site host names and the site's
model-gateway prefix are replaced by placeholders (`$REPO`, `$HOME`,
`$SCRATCH`, `$PREFIX`, `$TOOLS`, `site-endpoint`, ...). Model names, numbers,
timings and all outcomes are as recorded. Generation checkpoints were checked
against their stored SHA-256 before redaction and carry a recomputed one after
it; all 326 load. `python scripts/campaign.py report campaign/eval{1,2,3}.yaml`
in the unpacked code rebuilds `campaign/eval*/results.csv` and `summary.md`
byte for byte.

## Checked on this archive

- Fast pytest suite from the unpacked code: 190 passed (the full 195 with the
  slow n <= 5 corpus are in the execution record).
- The unpacked LaTeX source rebuilds to 160 pages, no undefined references.
